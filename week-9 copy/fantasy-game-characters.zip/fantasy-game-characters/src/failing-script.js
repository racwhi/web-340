/**
 * Author: Rachel White
 * Date: 12/22/2024
 * File Name: failing-script.js
 * Description: fantasy game character failing-script.js
 */
// TODO: Implement this script

throw new Error("This is an international error for testing.");
process.exit(1);
